from django.contrib import admin
from django.urls import path
from buss import views as v1

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', v1.aboutview, name='about'),  # About page
    path('calculate-fare/', v1.calculate_fare, name='calculate_fare'),
    path('timings/', v1.depot_timings, name='depot_timings'),
    path('mapppp/', v1.map_view, name='map_view'),
    path('generate/', v1.generate_pass, name='generate_pass'),
    path('list/', v1.pass_list, name='pass_list'),
    path('success/', v1.success_view, name='success_view'),
   
    path('cmplmn/', v1.file_complaint, name='cmpln'),  # Complaint page
    path('bsscc/', v1.bssc, name='bsscc'),
    path('cnll/', v1.cncl, name='cncl'),
    path('pnnl/', v1.ticket_temp, name='pnnl'),
    path('tickets/book/', v1.book_ticket, name='book_ticket'),
    path('pssc/', v1.pssss, name='bus_pass'),   # Booking URL
]

# Uncomment and modify the following lines if you have static or media files
# from django.conf import settings
# from django.conf.urls.static import static
# urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
# urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
